"use client"

import { useState } from "react"
import Head from "next/head"

export default function Home() {
  const [input, setInput] = useState("")
  const [response, setResponse] = useState(null)
  const [error, setError] = useState("")
  const [selectedFilters, setSelectedFilters] = useState([])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setResponse(null)

    try {
      const parsedInput = JSON.parse(input)
      const res = await fetch("/api/bfhl", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsedInput),
      })
      const data = await res.json()
      setResponse(data)
    } catch (err) {
      setError("Invalid JSON input")
    }
  }

  const handleFilterChange = (e) => {
    const value = e.target.value
    setSelectedFilters(
      e.target.checked ? [...selectedFilters, value] : selectedFilters.filter((item) => item !== value),
    )
  }

  const filteredResponse = response
    ? Object.fromEntries(
        Object.entries(response).filter(
          ([key]) => selectedFilters.includes(key) || !["numbers", "alphabets", "highest_alphabet"].includes(key),
        ),
      )
    : null

  return (
    <div className="container mx-auto p-4">
      <Head>
        <title>ABCD123</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <h1 className="text-2xl font-bold mb-4">BFHL API Tester</h1>
        <form onSubmit={handleSubmit} className="mb-4">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full p-2 border rounded"
            rows="4"
            placeholder='Enter JSON (e.g., { "data": ["A","C","z"] })'
          />
          <button type="submit" className="mt-2 px-4 py-2 bg-blue-500 text-white rounded">
            Submit
          </button>
        </form>
        {error && <p className="text-red-500">{error}</p>}
        {response && (
          <div>
            <h2 className="text-xl font-bold mb-2">Response Filters:</h2>
            <div className="mb-4">
              {["numbers", "alphabets", "highest_alphabet"].map((filter) => (
                <label key={filter} className="mr-4">
                  <input
                    type="checkbox"
                    value={filter}
                    checked={selectedFilters.includes(filter)}
                    onChange={handleFilterChange}
                  />{" "}
                  {filter.charAt(0).toUpperCase() + filter.slice(1)}
                </label>
              ))}
            </div>
            <h2 className="text-xl font-bold mb-2">Filtered Response:</h2>
            <pre className="bg-gray-100 p-4 rounded">{JSON.stringify(filteredResponse, null, 2)}</pre>
          </div>
        )}
      </main>
    </div>
  )
}


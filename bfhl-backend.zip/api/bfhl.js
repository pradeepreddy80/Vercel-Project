import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({ operation_code: 1 }, { status: 200 })
}

export async function POST(request) {
  try {
    const body = await request.json()
    const { data } = body

    if (!Array.isArray(data)) {
      return NextResponse.json({ is_success: false, error: "Invalid input" }, { status: 400 })
    }

    const numbers = data.filter((item) => !isNaN(item))
    const alphabets = data.filter((item) => isNaN(item) && item.length === 1)
    const highestAlphabet =
      alphabets.length > 0 ? [alphabets.reduce((a, b) => (a.toLowerCase() > b.toLowerCase() ? a : b))] : []

    const response = {
      is_success: true,
      user_id: "john_doe_17091999",
      email: "john@xyz.com",
      roll_number: "ABCD123",
      numbers,
      alphabets,
      highest_alphabet: highestAlphabet,
    }

    return NextResponse.json(response, { status: 200 })
  } catch (error) {
    return NextResponse.json({ is_success: false, error: "Server error" }, { status: 500 })
  }
}


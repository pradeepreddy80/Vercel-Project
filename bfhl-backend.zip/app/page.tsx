"use client"

import Home from "../pages/index"

export default function SyntheticV0PageForDeployment() {
  return <Home />
}